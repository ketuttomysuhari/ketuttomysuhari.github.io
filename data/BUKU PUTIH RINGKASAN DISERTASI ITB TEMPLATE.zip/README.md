TEMPLATE DISERTASI VERSI 1.0

Disusun tanggal 5 Januari 2024.
Disclaimer:  Template ini disusun oleh Ketut Tomy Suhari (Doktor GD 2020)
****************************************************************************************************

Beberapa catatan:
1. Untuk alasan kemudahan, disarankan template RINGKASAN DISERTASI ini di-compile melalui situs overleaf.com
2. Jika ada pertanyaan, saran, atau menemukan bug, hubungi saya: ksuhari@lecturer.itn.ac.id