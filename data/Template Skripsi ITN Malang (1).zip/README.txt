TEMPLATE BUKU TA VERSI 1.0

Disusun tanggal 11 Februari 2023.
Disclaimer:  Template ini disusun dari template sebelumnya yang disusun oleh Ketut Tomy Suhari (GD 2013)
****************************************************************************************************

Beberapa catatan:
1. Untuk alasan kemudahan, disarankan template SKRIPSI ini di-compile melalui situs overleaf.com
2. Jika ada pertanyaan, saran, atau menemukan bug, hubungi saya: ksuhari@lecturer.itn.ac.id